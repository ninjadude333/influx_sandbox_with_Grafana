# Mirror UDF

Each example in this directory should implement an mirroring UDF.

* Wants and provides a stream edge.
* Returns each point received back to Kapacitor unmodified.

